﻿namespace Raiding.Global
{
    interface GlobalConst
    {
        protected const int druidPower = 80;
        protected const int paladinPower = 100;
        protected const int roguePower = 80;
        protected const int warriorPower = 100;
    }
}