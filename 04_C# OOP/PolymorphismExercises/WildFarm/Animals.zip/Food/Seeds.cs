﻿namespace WildFarm.Food
{
    public class Seeds : Foods
    {
        public Seeds(int quantity) 
            : base(quantity)
        {
        }
    }
}