﻿namespace WildFarm.Food
{
    public class Vegetable : Foods
    {
        public Vegetable(int quantity) 
            : base(quantity)
        {
        }
    }
}
