﻿namespace WildFarm.Food
{
    public class Fruit : Foods
    {
        public Fruit(int quantity) 
            : base(quantity)
        {
        }
    }
}