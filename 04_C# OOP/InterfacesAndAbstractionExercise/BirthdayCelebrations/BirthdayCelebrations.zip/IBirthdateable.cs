﻿namespace BirthdayCelebrations
{
    public interface IBirthdateable
    {
        public string BirthDate { get; }
    }
}
