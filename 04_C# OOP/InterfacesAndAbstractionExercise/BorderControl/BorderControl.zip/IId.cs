﻿namespace BorderControl
{
    public interface IId
    {
        public string Id { get; }
    }
}
