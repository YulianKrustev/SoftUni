﻿namespace MilitaryElite.Core
{
    public interface IEngine
    {
        public void Run();
    }
}
