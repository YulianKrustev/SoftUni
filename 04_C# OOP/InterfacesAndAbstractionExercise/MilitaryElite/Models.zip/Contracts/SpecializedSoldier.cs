﻿namespace MilitaryElite.Contracts
{
    public interface SpecializedSoldier
    {
    }
}