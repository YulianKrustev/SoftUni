﻿namespace MilitaryElite.Contracts
{
    public interface IRepair
    {
        string PartName { get; }
        int HoursWorkd { get; }
    }
}
