﻿namespace FoodShortage
{
    public interface IBirthdateable
    {
        public string BirthDate { get; }
    }
}
