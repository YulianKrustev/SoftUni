﻿namespace Telephony
{
    public interface ICallable
    {
        void Calling(string number);
    }
}
