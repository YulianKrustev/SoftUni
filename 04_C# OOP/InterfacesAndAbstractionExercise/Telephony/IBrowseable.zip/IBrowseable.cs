﻿namespace Telephony
{
    public interface IBrowseable
    {
        void Browsing(string address);
    }
}
