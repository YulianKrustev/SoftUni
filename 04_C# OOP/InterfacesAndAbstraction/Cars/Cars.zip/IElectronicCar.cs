﻿namespace Cars
{
    interface IElectronicCar
    {
        int Battery { get; set; }
    }
}
