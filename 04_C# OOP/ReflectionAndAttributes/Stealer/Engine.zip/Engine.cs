﻿using System;

namespace Stealer
{
    public class Engine
    {
        public void Run()
        {
            Spy spy = new Spy();
            string result = spy.AnalyzeAccessModifiers("Stealer.Hacker");
            Console.WriteLine(result);
        }
    }
}